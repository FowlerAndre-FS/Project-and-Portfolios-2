
# Instructions 
Update this document where indicated (brackets). Replace text inside the brackets with your own information. For example: Course Name should be the name of this course, and not the generic words "Course Name".

**Note:** As you complete each item, also update reference links where indicated below. 

<br>

## [ Course Name <-- Replace all text in brackets ] 

* **[ File I/O ]**
* **[ Andre Fowler Jr ]**
* **[ 10/14/2020 ]**

This paper addresses some of the topic matter covered in research and activity this week. Be sure to include reference links below to the research and information you used to complete this assignment.

## Topic: Working with Data
Update the information below to demonstrate your knowledge on this topic.   

**1. Using Dictionary values as a Data Source.**

A dictionary is useful for working with data. Identify what's wrong with the code block below. How would you fix the issue(s)? The output to console should match the "**Expected Output**" shown below. 

Identify at least three issues with the code and how each can be fixed... 

- **Issue 1:** [ keyvalue C# is not in the dictionary list and this can be fixed  by adding C# as key in the Dictionary]  
- **Issue 2:** [ {item} is written in double quatations and  this can be fixed by adding + before and after item and end double quatations will end and start before and after + symbol and brackets also removed]  
- **Issue 3:** [ SQL value is not added and this can be fixed by adding myBooks["SQL"].Add("Practical SQL");]
-**Issue 4** [Console.WriteLine($"\n*** {item} *******") programming language name is not printing in console because program is printing keyvaluepair instance not the keyvaluepair  key which is the programming language name of the books.]

  
    
```c#
            Dictionary<string, List<string>> myBooks = new Dictionary<string, List<string>>()
            {
                { "C", new List<string>()},
                { "JavaScript", new List<string>() },
                { "SQL", new List<string>() }
            };

            myBooks["C#"].Add("Visual C# Step by Step");
            myBooks["JavaScript"].Add("Learning JavaScript Design Patterns");

            foreach (KeyValuePair<string, List<string>> item in myBooks)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\n*** {item} *******");
                Console.ForegroundColor = ConsoleColor.White;
                foreach (var book in item.Value)
                {
                    Console.WriteLine(book);
                }
            }

```

**Expected Output:** 

```
*** C# *******
Visual C# Step by Step

*** JavaScript *******
Learning JavaScript Design Patterns

*** SQL *******
Practical SQL

```

<br>


**2. Using a User object as a data source**

A dictionary can store objects. Imagine a User class that contains the following properties: **Name**, **City**, **State**, and **Id**. The code block below instantiates a new instance of this class and gives that instance (i.e. the new user object) some values. With that new object created, we add it to a dictionary. We then cycle through the dictionary to print out the new user object values to the console. 

Identify what's wrong with the code block below. How would you fix the issue(s)? The output to console should match the "**Expected Output**" shown below. 

Identify at least three issues with the code and how each can be fixed... 

- **Issue 1:** [ foreach loop cannot operate due to User class object and this can be fixed by adding definition of getEnumerator]  
- **Issue 2:** [ users in outer foreachloop will print nothing and this can be fixed by putting user instead of users in the outer foreach loop]  
- **Issue 3:** [ {userCatagory} is written in double quatations and  this can be fixed by adding + symbol before and after userCatagory and double quatations will end and start before and after + symbol and brackets also removed]

 
```c#
using System;
using System.Collections.Generic;

namespace Lab
{
    public class App
    {
        public App()
        {
            User user = new User("John Doe", "Winter Park", "Florida", 1234);

            Dictionary<string, List<User>> users = new Dictionary<string, List<User>>();

            users.Add("Members", new List<User>());
            users["Members"].Add(user);

            foreach (KeyValuePair<string, List<User>> userCategory in users)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\n*** {userCategory} *******");
                Console.ForegroundColor = ConsoleColor.White;

                foreach (var individual in userCategory)
                {
                    Console.WriteLine(individual.Name);
                    Console.WriteLine(individual.City);
                    Console.WriteLine(individual.State);
                    Console.WriteLine(individual.Id);
                }
            }
        }
    }

    public class User
    {
        public string Name { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Id { get; set; }

        public User(string name, string city, string state, int id)
        {
            Console.WriteLine("User Created!");
        }
    }
}


```


**Expected Output:** 

```
User Created!

*** Members *******
John Doe
Winter Park
Florida
1234

```

<br>


## Topic: Read and Write Data
An application has more flexibility when it is able to both store and retrieve data. Using C# and the File, StreamReader, and StreamWriter classes gives us this ability. Any data read from a file can be stored for later use by using data structures. For example, a newly created User object (instance of the User class) may have a Name property. Data read from a file can be used to update the name value of that new instance.     
 

**1. From your research and use of the StreamReader class, respond to the following.**


- **A.** What namespace is used with the StreamReader class?: [ System.IO namespace]
- **B.** Describe how you would check to see if a file has any additional lines to read when using the StreamReader class: 
	     [  while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                } ]  

- **C.** When creating a new StreamReader, what information is expected after the keyword "new"?

[ A FileStream object is passed into constructer of StreamReader class after the keyword "new"
example:-
FileStream fout = new FileStream("user.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fout);]


**2. Demonstrate how to use the StreamWriter class to write to a file. Include the following: A using statement, a StreamWriter object, and use of the File.AppendText() method. Explain each part of the code in your own words.**

```

[
1- A USING STATEMENT
Using System.IO;

2-Creation of StreamWriter object
 FileStream fin = new FileStream("user.txt", FileMode.Append);
                StreamWriter sw = new StreamWriter(fin);

3-Use of File.AppendText() function
AppendText() is an inbuilt File class method which is used to create a StreamWriter that appends UTF-8 encoded text to an existing file else it creates a new file 
if the specified file does not exist.]

    

**3. What is the difference between a property and an auto implemented property? When would you use one over the other..**

[  
Auto Implemented property                                      
public class Population                                       
{
    public int Male { get; set; }
    public int Female { get; set; }
}


Property
public class Population
{
    public int male;
    public int Male
    {
        get
        {
            return male;
        }
        set
        {
            male = value;
        }
    }

The compiler creates the internal object and the accessors
 (get and set operations) for the auto-implemented properties so they’re mutable.
Properties and auto-implemented properties seem identical in practical terms and in fact they’re in simple scenarios like previous 
but in complex classes that contain methods as well as significant logic.
]



**4. If a class member contains the keyword "static", how do you use this outside of the defining class?. Provide an example with an explanation.**  


```

[ Members of static classes can be accessed directly using the class name followed by a (.) and class member name. Class Members can be methods, fields, properties, or events. 
A static class can contain only the static members while a non-static class can contain static members 
public class Test
{
   public static int value;
}

Test.value=3;   ]

```

<br>

# Reference Links
Replace the example references below with your own independent research. Do not use material already provided to you in this class. Two or more references are needed for each topic below.

**Working with Data**  
[Microsoft](https://docs.microsoft.com/en-us/learn/paths/csharp-data/)  

[This resource helped me to understand about static class,static data members,static methods. This is a learning path on microsoft to allow us to learn in detail.]


[Guru99](https://www.guru99.com/c-sharp-access-database.html)  

[How did this resource help you?
This source allowed me to learn about databases and the common concepts used in today industry.]


**Read and Write Data**  
[FireBase](https://firebase.google.com/docs/database/web/read-and-write)

[How did this resource help you? 
This website showed me that you can write data offline by writing the data locally.]


[Microsoft](https://docs.microsoft.com/en-us/dotnet/standard/io/how-to-read-and-write-to-a-newly-created-data-file)  

[How did this resource help you? This website was a reference to when i was researching System.IO... This presented that when you create a new file use FileMode.Create instead of FileMode.CreateNew ]






